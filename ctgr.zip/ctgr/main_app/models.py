import bcrypt
from django.db import models
import re
from datetime import datetime

class UserManager(models.Manager):
    def registration_validator(self, post_data):
        errors = {}

        # validate name
        if len(post_data["first_name"]) < 2:
            errors["first_name"] = "First name must be at least 2 characters"
        
        if len(post_data['last_name']) < 2:
            errors['last_name'] = "Last name must be at least 2 characters"
        
        #  validate tribal id
        tribal_id_input = int(post_data['tribal_id'])
        valid_id = []
        for member in range(1000, 1100):
            valid_id.append(member)
        if tribal_id_input not in valid_id:
            errors['tribal_id'] = "You must be an enrolled tribal member to register"
        

        # validate email
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(post_data['email']):    # test whether a field matches the pattern            
            errors['email'] = "Invalid email address!"
        else:
            user_list = User.objects.filter(email = post_data['email'])
            if len(user_list) > 0:
                errors['email'] = "Email is already in use"
        
        # validate address info
        if len(post_data['address']) < 2:
            errors['address'] = "You must enter a valid address"
        
        if len(post_data['city']) < 1:
            errors['city'] =" You must enter a valid city"
        
        if len(post_data['state']) < 1:
            errors['state'] =" You must enter a valid state format"
        elif len(post_data['state']) > 2:
            errors['state'] =" You must enter a valid state format"
        
        if len(post_data['zipcode']) < 1:
            errors['zipcode'] =" You must enter a valid postal code"

        # validate password
        if len(post_data['password']) < 8:
            errors['password'] = "password must be at least 8 characters"
        if post_data['password'] != post_data['confirm_password']:
            errors['confirm_password'] = "Password and confirm password do not match!"
        
        return errors

        
    def login_validator(self, post_data):
        errors = {}

        users_list = User.objects.filter(email = post_data['email'])
        # found a user with filtered email (grabs ALL user info)
        if len(users_list) > 0:
            user = users_list[0]
        # do passwords match what is in db?
            if not bcrypt.checkpw(post_data['password'].encode(), user.password.encode()):
                errors['password'] = "Invalid Credentials"
        else:
            errors['email'] = "Invalid Credentials"

        return errors


    def info_validator(self, post_data):
        errors = {}

        # validate name
        if len(post_data["first_name"]) < 2:
            errors["first_name"] = "First name must be at least 2 characters"
        
        if len(post_data['last_name']) < 2:
            errors['last_name'] = "Last name must be at least 2 characters"
        
        # validate tribal id
        tribal_member = TribalMember.tribal_member
        if (post_data['tribal_id']) != tribal_member:
            errors['tribal_id'] = "You must be an enrolled tribal member to register"

        # validate email
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(post_data['email']):    # test whether a field matches the pattern            
            errors['email'] = "Invalid email address!"
        else:
            user_list = User.objects.filter(email = post_data['email'])
            if len(user_list) > 1:
                errors['email'] = "Email is already in use"
        
        # validate address info
        if len(post_data['address']) < 2:
            errors['address'] = "You must enter a valid address"
        
        if len(post_data['city']) < 1:
            errors['city'] =" You must enter a valid city"
        
        if len(post_data['state']) < 1:
            errors['state'] =" You must enter a valid state format"
        elif len(post_data['state']) > 2:
            errors['state'] =" You must enter a valid state format"
        
        if len(post_data['zipcode']) < 1:
            errors['zipcode'] =" You must enter a valid postal code"

        # validate password
        if len(post_data['password']) < 8:
            errors['password'] = "password must be at least 8 characters"
        if post_data['password'] != post_data['confirm_password']:
            errors['confirm_password'] = "Password and confirm password do not match!"
        
        return errors


class User(models.Model):
    first_name = models.CharField(max_length = 65)
    last_name = models.CharField(max_length = 65)
    tribal_id = models.CharField(max_length = 10)
    address = models.CharField(max_length = 255)
    city = models.CharField(max_length = 65)
    state = models.CharField(max_length = 2)
    zipcode = models.CharField(max_length = 20)
    email = models.CharField(max_length = 75)
    password = models.CharField(max_length = 255)
    profile_pic = models.ImageField(upload_to='images', blank = True, default='default.png')
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = UserManager()

class TribalMember(models.Model):
    tribal_member = models.CharField(max_length = 8)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)

class MessageManager(models.Manager):
    def message_validator(self, post_data):
        errors = {}

        if len(post_data['message']) < 1:
            errors['message'] = "you must enter a message"

        return errors


class Message(models.Model):
    message = models.TextField()
    user = models.ForeignKey(User, related_name="messages", on_delete = models.CASCADE)
    likes = models.ManyToManyField(User, related_name ="liked_messages")
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = MessageManager()

    def total_likes(self):
        return self.likes.count()

class CommentManager(models.Manager):
    def comment_validator(self, post_data):
        errors = {}

        if len(post_data['comment']) < 1:
            errors['comment'] = "you must enter a comment"

        return errors


class Comment(models.Model):
    comment = models.TextField()
    message = models.ForeignKey(Message, related_name ="comments", on_delete =  models.CASCADE)
    user = models.ForeignKey(User, related_name="comments", on_delete = models.CASCADE)
    likes = models.ManyToManyField(User, related_name ="liked_comments")
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = CommentManager()

    def total_comment_likes(self):
        return self.likes.count()