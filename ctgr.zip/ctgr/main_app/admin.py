from django.contrib import admin
from . models import *
from contact.models import Contact

admin.site.register(User)
admin.site.register(TribalMember)
admin.site.register(Message)
admin.site.register(Comment)
admin.site.register(Contact)

