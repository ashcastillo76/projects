import bcrypt
from django.contrib import messages
from django.shortcuts import render, redirect
from .models import User, Trip

def index(request):
    # if the user is already logged in session, it will redirect to the logged in page (dashboard) named success
    if "user_id" in request.session:
        return redirect("/dashboard")

    return render(request, "index.html")

def register(request):
    errors = User.objects.registration_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        hash = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        new_user = User.objects.create(
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            email = request.POST['email'],
            password = hash
        )
        request.session['user_id'] = new_user.id
        return redirect("/dashboard")

def login(request):
    errors = User.objects.login_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        user = User.objects.get(email = request.POST['email'])
        request.session['user_id'] = user.id
    return redirect("/dashboard")

def logout(request):
    del request.session['user_id']
    return redirect("/")

def dashboard(request):
    # if the user isn't logged in, then it redirects to the login page add this code to any function that can only be accessed by logged in members
    if "user_id" not in request.session:
        return redirect('/')
    
    context ={
        # finds the id of the person in session and the user that matches that id in the list
        "current_user": User.objects.get(id= request.session['user_id']),
        "all_users": User.objects.all(),
        "all_trips": Trip.objects.all(),
        "traveler_trips": Trip.objects.filter(traveler = User.objects.get(id= request.session['user_id'])),
        "other_trips": Trip.objects.exclude(traveler =User.objects.get(id= request.session['user_id']))
            }
    return render(request, "dash.html", context)

def new_trip(request):
    context={
        "current_user": User.objects.get(id = request.session['user_id'])
    }
    return render(request, "create_trip.html", context)

def create_trip(request):
    errors = Trip.objects.trip_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/trips/new')
    else:
        current_user = User.objects.get(id = request.session['user_id'])
        new_trip = Trip.objects.create(
            destination = request.POST['destination'],
            start = request.POST['start'],
            end = request.POST['end'],
            plan = request.POST['plan'],
            traveler = current_user
        )
    return redirect("/dashboard")

def display_trip(request, trip_id):
    context = {
        "current_user": User.objects.get(id = request.session['user_id']),
        "all_trips": Trip.objects.get(id = trip_id)
    }
    return render(request, "trip.html", context)

def edit_trip(request, trip_id):
    context ={
            "current_user": User.objects.get(id = request.session['user_id']),
            "trip": Trip.objects.get(id = trip_id)
            }
    return render(request, "edit_trip.html", context)

def update_trip(request, trip_id):
    errors =  Trip.objects.trip_validator(request.POST)
    
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f"/trips/{trip_id}/edit")
    else:
        trip = Trip.objects.get(id = trip_id)
        trip.destination = request.POST['destination']
        trip.start = request.POST['start']
        trip.end = request.POST['end']
        trip.plan = request.POST['plan']
        trip.save()
    return redirect("/dashboard")

def remove_trip(request, trip_id):
    trip = Trip.objects.get(id = trip_id)
    trip.delete()
    return redirect("/dashboard")

def join(request):
    pass