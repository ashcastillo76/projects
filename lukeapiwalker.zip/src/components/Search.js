import { navigate } from '@reach/router';
import React, {useState} from 'react';



const Search = () =>{
    const [option, setOption] = useState("");
    const [id, setId] = useState(0);

    const searchHandler = e => {
        e.preventDefault();
        if(option === "People"){
        navigate(`/people/${id}`)
        }
        else{
        navigate(`/planets/${id}`)
    }
    }
    return (
        <>
            <form onSubmit= {searchHandler}>
                <label htmlFor="search">Search For:</label>
                <select className="dropDown" onChange={ e => setOption(e.target.value)} >
                    {
                        console.log(option)
                    }
                    <option className="dropDown" value="People">People</option>
                    <option className="dropDown" value="Planet">Planet</option>
                </select>
                <label htmlFor="objectId">ID:</label>
                <input type="number" className="number" onChange={ e => setId(e.target.value)} />
                <input className="button" type="submit" value="Search" />
            </form>
        </>
    )
}


export default Search;
