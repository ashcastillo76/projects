import bcrypt
from django.contrib import messages
from django.shortcuts import render, redirect
from django.urls import reverse
from .models import *

def index(request):
    # if the user is already logged in session, it will redirect to the logged in page (dashboard) named success
    if "user_id" in request.session:
        return redirect("/dashboard")
    return render(request, "index.html")

def view_login_reg(request):
    if "user_id" in request.session:
        return redirect("/dashboard")
    else:
        return render(request, "reg_login.html")

def register(request):
    errors = User.objects.registration_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/login_home')
    else:
        hash = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        new_user = User.objects.create(
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            tribal_id = request.POST['tribal_id'],
            address = request.POST['address'],
            city = request.POST['city'],
            state = request.POST['state'],
            zipcode = request.POST['zipcode'],
            profile_pic = request.POST['profile_pic'],
            email = request.POST['email'],
            password = hash
        )
        request.session['user_id'] = new_user.id
        return redirect("/dashboard")

def login(request):
    errors = User.objects.login_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/login_home')
    else:
        user = User.objects.get(email = request.POST['email'])
        request.session['user_id'] = user.id
    return redirect("/dashboard")

def logout(request):
    del request.session['user_id']
    return redirect("/")

def dashboard(request):
    # if the user isn't logged in, then it redirects to the login page add this code to any function that can only be accessed by logged in members
    if "user_id" not in request.session:
        return redirect('/login_home')
    
    
    context ={
        "logged_in_user": User.objects.get(id= request.session['user_id']),
        "all_messages" : Message.objects.all(),
        "all_comments": Comment.objects.all(),

                }
    return render(request, "dash.html", context)

def logout(request):
    del request.session['user_id']
    return redirect("/")

def profile(request, user_id):
    context ={
        "logged_in_user": User.objects.get(id= request.session['user_id']),
    }
    return render(request, "profile.html", context)

def update_profile(request, user_id):
    user =User.objects.get(id =request.session['user_id'])
    errors = User.objects.info_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f'/profile/{user.id}')
    else:
        hash = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        user = User.objects.get(id = user_id)
        user.first_name = request.POST['first_name']
        user.last_name = request.POST['last_name']
        user.tribal_id = request.POST['tribal_id']
        user.email = request.POST['email']
        user.address = request.POST['address']
        user.city = request.POST['city']
        user.zipcode = request.POST['zipcode']
        user.profile_pic = request.POST['profile_pic']
        user.password = hash
        user.save()
    return redirect("/dashboard")

def post_message(request):
    errors = Message.objects.message_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/dashboard')
    else:
        logged_in_user = User.objects.get(id = request.session['user_id'])
        Message.objects.create(
        message = request.POST['message'],
        user = logged_in_user
        )
        return redirect('/dashboard')

def post_comment(request):
    errors = Comment.objects.comment_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/dashboard')
    else:
        this_user = User.objects.get(id= request.session['user_id'])
        this_message = Message.objects.get(id = request.POST['message_id'])
        Comment.objects.create(
        comment = request.POST['comment'],
        user= this_user,
        message = this_message
        )
        return redirect('/dashboard')


def delete_message(request, message_id):
    message_delete = Message.objects.get(id=message_id)
    message_delete.delete()
    return redirect('/dashboard')

def like_message(request, message_id):
    message = Message.objects.get(id = message_id)
    message.likes.add(request.session['user_id'])
    return redirect('/dashboard')

def like_comment(request, comment_id):
    comment = Comment.objects.get(id = comment_id)
    comment.likes.add(request.session['user_id'])
    return redirect('/dashboard')



