from django.urls import path
from . import views

urlpatterns =[
    path('', views.index),
    path('register', views.register),
    path('login', views.login),
    path('logout', views.logout),
    # read many
    path('dashboard', views.dashboard),
    # create
    path('trips/new', views.new_trip),
    path('trips/create', views.create_trip),
    # read one
    path('trips/<int:trip_id>', views.display_trip),
    # update
    path('trips/<int:trip_id>/edit', views.edit_trip),
    path('trips/<int:trip_id>/update', views.update_trip),
    # delete
    path('trips/<int:trip_id>/delete', views.remove_trip),
    path('join', views.join)
]