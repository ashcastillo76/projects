import bcrypt
from django.db import models
import re
from datetime import datetime

class UserManager(models.Manager):
    def registration_validator(self, post_data):
        errors = {}

        # validate name
        if len(post_data['first_name']) < 2:
            errors['first_name'] = "First name must be at least 2 characters"
        
        if len(post_data['last_name']) < 2:
            errors['last_name'] = "Last name must be at least 2 characters"
        
        # validate email
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(post_data['email']):    # test whether a field matches the pattern            
            errors['email'] = "Invalid email address!"
        else:
            user_list = User.objects.filter(email = post_data['email'])
            if len(user_list) > 0:
                errors['email'] = "Email is already in use"

        # validate password
        if len(post_data['password']) < 8:
            errors['password'] = "password must be at least 8 characters"
        if post_data['password'] != post_data['confirm_password']:
            errors['confirm_password'] = "Password and confirm password do not match!"
        
        return errors

        
    def login_validator(self, post_data):
        errors = {}

        users_list = User.objects.filter(email = post_data['email'])
        # found a user with filtered email (grabs ALL user info)
        if len(users_list) > 0:
            user = users_list[0]
        # do passwords match what is in db?
            if not bcrypt.checkpw(post_data['password'].encode(), user.password.encode()):
                errors['password'] = "Invalid Credentials"
        else:
            errors['email'] = "Invalid Credentials"

        return errors

class User(models.Model):
    first_name = models.CharField(max_length = 65)
    last_name = models.CharField(max_length = 65)
    email = models.CharField(max_length = 75)
    password = models.CharField(max_length = 255)
    # trips = a list of travelers
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = UserManager()

class TripManager(models.Manager):
    def trip_validator(self, post_data):
        errors = {}
        print(post_data)
        # validate name
        if len(post_data['destination']) < 3:
            errors['destination'] = "The destination must be at least 3 characters"
        
        if len(post_data['destination']) < 1:
            errors['destination'] = "You must enter a destination"

        if (post_data['start']) == "":
            errors['start']="You must enter a start date" 
        elif datetime.now() < (datetime.strptime(post_data['start'], "%Y-%m-%d")):
            errors['start'] = "Time Travel is not allowed"


        if (post_data['end']) == "":
            errors['end']="You must enter an end date"
        elif (datetime.strptime(post_data['start'], "%Y-%m-%d"))> (datetime.strptime(post_data['end'], "%Y-%m-%d")):
            errors['end'] = "The end of the trip must be after the start date"
        
        
        if len(post_data['plan']) < 1:
            errors['plan'] = "You must enter plan details for this trip"
        
        if len(post_data['plan']) < 3:
            errors['plan'] = "You must have at least three characters in your plan"
        
        return errors


class Trip(models.Model):
    destination = models.CharField(max_length = 255)
    start = models.DateField()
    end = models.DateField()
    plan = models.TextField()
    traveler = models.ForeignKey(User, related_name ="trips", on_delete = models.CASCADE)
    created_at = models.DateTimeField(auto_now_add = True,)
    updated_at = models.DateTimeField(auto_now = True)
    objects = TripManager()