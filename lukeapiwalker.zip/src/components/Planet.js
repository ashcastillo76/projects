import React from 'react'
import {useState, useEffect} from 'react';
import axios from 'axios';

const Planet= props =>{
    const {id} = props;
    const [planet, setPlanet] = useState({
        name: "",
        climate: "",
        terrain: "",
        surface_water: "",
        population: "",
    });

useEffect(() => {
        axios.get(`https://swapi.dev/api/planets/${id}`)
        .then(response => setPlanet(response.data))
        .catch(err => console.log(err));
    }, [id])

    return (
        <div className="wrapper">
            <h1>{planet.name}</h1>
            <h3>Climate: {planet.climate}</h3>
            <h3>Terrain: {planet.terrain}</h3>
            <h3>Surface Water: {planet.surface_water}</h3>
            <h3>Population: {planet.population}</h3>
        </div>
        )
}


export default Planet;
