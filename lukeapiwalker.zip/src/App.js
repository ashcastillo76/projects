import Search from './components/Search';
import People from './components/People';
import Planet from './components/Planet';
import Unsuccessful from './components/Unsucessful';
import {Router} from '@reach/router';
import './App.css';

function App() {
  return (
    <div className="App">
        <Search/>
        <>
        <Router>
          <People path="/people/:id/" />
          <Planet path="/planets/:id/" />
          <Unsuccessful path ="/Unsuccessful/" />
        </Router>
        </>
    </div>
  );
}

export default App;
