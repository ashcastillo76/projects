from django.urls import path
from . import views

urlpatterns =[
    path('', views.index),
    path('login_home', views.view_login_reg),
    path('register', views.register),
    path('login', views.login),
    path('logout', views.logout),
    # read many
    path('dashboard', views.dashboard),
    # read one
    path('profile/<int:user_id>', views.profile),
    path('update/<int:user_id>', views.update_profile),
    path('post_message', views.post_message),
    path('post_comment', views.post_comment),
    path('delete/<int:message_id>', views.delete_message),
    path('like_message/<int:message_id>', views.like_message),
    path('like_comment/<int:comment_id>', views.like_comment),
    
]