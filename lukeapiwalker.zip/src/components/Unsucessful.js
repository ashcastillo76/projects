import React from 'react'
import obi from '../assets/images/obi.jpg';

export default function Unsucessful() {
    return (
        <div>
            <img src={obi} width= "500" margin-top="50" alt="These aren't the droids you're looking for"/>
        </div>
    )
}
