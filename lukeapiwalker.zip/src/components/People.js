import React from 'react';
import {useState, useEffect} from 'react';
import axios from 'axios';
import { navigate } from '@reach/router';


const People= props => {
    const {id} = props;
    const [person, setPerson] = useState({
        name:"",
        height: "",
        mass: "",
        hair_color: "",
        skin_color: "",
    });


useEffect (() => {
        axios.get(`https://swapi.dev/api/people/${id}`)
        .then(response => setPerson(response.data))
        .catch(err => {
            navigate("/Unsuccessful");
    })
}, [id])

    return (
        <div className="wrapper">
            <h1>{person.name}</h1>
            <h3>Height: {person.height} centimeters</h3>
            <h3>Mass: {person.mass} kilograms</h3>
            <h3>Hair Color: {person.hair_color}</h3>
            <h3>Skin Color: {person.skin_color}</h3>
        </div>
    )
}

export default People
